package com.javabykiran.JBK;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JbkApplication {

	public static void main(String[] args) {
		SpringApplication.run(JbkApplication.class, args);
	}

}
